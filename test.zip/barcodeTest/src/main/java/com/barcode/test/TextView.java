package com.barcode.test;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.font.TextAttribute;
import java.awt.geom.Rectangle2D;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TextView extends AttrView {
	private static Logger log = LoggerFactory.getLogger(TextView.class);
	private static final long serialVersionUID = 1L;
	
	protected int maxLength = -1;
	
	@Override
	protected void deserialize(JsonNode node) {
		super.deserialize(node);
		
		if(node.has("maxLength")) {
			maxLength = node.get("maxLength").getIntValue();
		}
	}

	@Override
	protected void draw(Graphics2D graphics, Map<String, Object> map) {
		super.draw(graphics, map);
		String text = getStringData(map);

		log.debug("text: [" + text + "]");
		
		if(text == null || text.trim().length() < 1) {
			return;
		}
		
		if(maxLength > 0) {
			if(text.length() > maxLength) {
				text = text.substring(0, maxLength).trim();
			}
		}
		
		Color color = getColor();
		log.debug("color: " + color);
		graphics.setColor(color);

		Font font = getFont();
		if(text.length() > 3) {
			if(fontAttrs != null) {
				if(fontAttrs.getTracking() > 0) {
					float maxValue = maxLength==0?20:maxLength;
					float tracking = fontAttrs.getTracking() - (text.length() - 3)/maxValue *0.7f;
					if(tracking < 0) { 
						tracking = 0;
					} 

					fontAttrs.setTracking(tracking);
					font = fontAttrs.derivedFont(font);
					log.debug("tracking: " + tracking);
				}
			}
		}

		log.debug("font: " + font);
		graphics.setFont(font);
		FontMetrics fontMetrics = graphics.getFontMetrics(font);
		
		Rectangle2D rect = fontMetrics.getStringBounds(text, graphics);
		
		int drawX = position.x;
		if(ALIGN_RIGHT.equalsIgnoreCase(ALIGN_RIGHT)) {
			drawX = drawX - fontMetrics.stringWidth(text) + (fontAttrs==null?0:(int)(fontAttrs.getTracking() * font.getSize()));
		}
		
		int drawY = position.y + (fontMetrics.getAscent() - fontMetrics.getDescent());

		
		log.debug("drawString : " + drawX + ", " + drawY + " - " + text);
		
		graphics.drawString(text, drawX, drawY);
	}
}
