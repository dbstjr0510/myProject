package com.barcode.test;

import java.io.IOException;
import java.io.InputStream;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.ObjectCodec;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.module.SimpleModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ViewDeserializer extends JsonDeserializer<View> {
	private static Logger log = LoggerFactory.getLogger(ViewDeserializer.class);
	
	@Override
	public View deserialize(JsonParser parser, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		View view = null;
		ObjectCodec codec = parser.getCodec();
		JsonNode node = codec.readTree(parser);
		
		String className = node.get("class").getTextValue();
		log.debug("View class:" + className);
		try {
			className = View.class.getPackage().getName() + "." + className;
			Class<?> clazz = Class.forName(className);
			if(View.class.isAssignableFrom(clazz)) {
				log.debug("View subclass:" + className);
				
				view = (View)clazz.newInstance();
				view.deserialize(node);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		log.debug("view:" + view);
		
		return view;
	}
	
	public static CardImage deserialize(InputStream is) {
		CardImage cardImage = null;

		try {
			SimpleModule module = new SimpleModule("ViewDeserializer", new Version(1, 0, 0, null));
			module.addDeserializer(View.class, new ViewDeserializer());
			
			ObjectMapper mapper = new ObjectMapper();
			mapper.registerModule(module);
			cardImage = (CardImage)mapper.readValue(is, View.class);
			cardImage.init();

			log.debug("End deserialize.");
			
		} catch(Exception e) {
			e.printStackTrace();
		}	
		
		return cardImage;
	}

}
