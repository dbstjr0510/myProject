package com.barcode.test;

import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImageView extends AttrView {
	private static Logger log = LoggerFactory.getLogger(ImageView.class);
	private static final long serialVersionUID = 1L;

	@Override
	protected void draw(Graphics2D graphics, Map<String, Object> map) {
		super.draw(graphics, map);
		Image img = (Image)getData(map);
		
		log.debug("img: [" + img + "]");
		
		if(img == null) {
			return;
		}
		
		graphics.drawImage(img, position.x, position.y, size.width, size.height, null);
	}
}
