package com.barcode.test;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.imageio.ImageIO;


public class CardImageTest {

	public static void main(String[] args) {
		try {
		    HashMap<String, Object> dataMap = new HashMap<String, Object>();
		    dataMap.put("userName", "전예지");
		    dataMap.put("userId", "20142403");
		    dataMap.put("colName", "조형예술디자인대학");
		    dataMap.put("deptName", "시각정보디자인학과");
		    dataMap.put("barcode", "201424031");
		    File pathToFile = new File("C:\\projects\\110540919_540.jpg");
		    Image image = ImageIO.read(pathToFile);
		    dataMap.put("photo", image);
		    
		    
		    CardImage finaceImageList = ViewDeserializer.deserialize(CardImageTest.class.getResourceAsStream("/card_image/finance_card.json"));
		    
		    finaceImageList.draw(dataMap);
		    finaceImageList.save("C:\\projects\\");
		    

		    CardImage nonFinaceImageList = ViewDeserializer.deserialize(CardImageTest.class.getResourceAsStream("/card_image/non_finance_card.json"));

		    nonFinaceImageList.draw(dataMap);
		    nonFinaceImageList.save("C:\\projects\\");
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		
		
		
		/*GeneratorIDCardImage.generateFinFrontTextImage("20142403", "전예지", "조형예술디자인대학", "시각정보디자인학과");
		GeneratorIDCardImage.generateFinFrontPhotoImage("20142403");
		GeneratorIDCardImage.generateFinBackImage("201424031");
		GeneratorIDCardImage.generateFrontTextImage("20142403", "전예지", "조형예술디자인대학", "시각정보디자인학과");
		GeneratorIDCardImage.generateFrontPhotoImage("20142403");
		GeneratorIDCardImage.generateBackImage("201424031");*/
		
	}
}
