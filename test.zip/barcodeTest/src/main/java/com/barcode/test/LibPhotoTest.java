package com.barcode.test;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.ubivelox.idt.util.Aes256InSpongy;

public class LibPhotoTest {

	public static void main(String[] args) {
		HttpHeaders headers = new HttpHeaders();
	    headers.setCacheControl("no-cache");
		headers.setContentType(MediaType.IMAGE_JPEG);
		
		String userId = Aes256InSpongy.decrypt(dummy, Aes256InSpongy.getSecretKey());
		byte[] data = userService.getLibPhotoDataFromUrl(userId);
		
		if(data == null) {
		    
		}
	    
	
	}

}
