package com.barcode.test;

public class FrameLayout extends Layout {
	private static final long serialVersionUID = 1L;

}
