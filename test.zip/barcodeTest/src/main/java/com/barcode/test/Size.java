package com.barcode.test;

import java.io.Serializable;

import org.codehaus.jackson.JsonNode;

public class Size implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public int width;
	public int height;
	
	public Size() {
	}
	
	public Size(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public static Size deserialize(JsonNode sizeNode) {
		if(sizeNode == null) return null;
		Size size = new Size(sizeNode.get("width").getIntValue(), sizeNode.get("height").getIntValue());
		return size;
	}
}
