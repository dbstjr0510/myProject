package com.barcode.test;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.EnumMap;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.oned.Code39Writer;

public class BarcodeView extends AttrView {
	private static Logger log = LoggerFactory.getLogger(BarcodeView.class);
	
	private static final long serialVersionUID = 1L;

	protected String type;
	
	@Override
	protected void deserialize(JsonNode node) {
		super.deserialize(node);
		
		if(node.has("type")) {
			type = node.get("type").getTextValue();
		}
	}

	@Override
	protected void draw(Graphics2D graphics, Map<String, Object> map) {
		super.draw(graphics, map);
		String text = getStringData(map);

		log.debug("barcode: [" + text + "]");
		
		if(text == null || text.trim().length() < 1) {
			return;
		}
		
		BufferedImage barcodeImage = getBarcode(text);

		log.debug("barcodeImage: [" + barcodeImage + "]");
		
		graphics.drawImage(barcodeImage, position.x, position.y, size.width, size.height, null);
		
	}
	
	protected BufferedImage getBarcode(String text) {
		BufferedImage bufferedImage = null;
		BitMatrix bitMatrix = null;
		
		try {
			if("code39".equalsIgnoreCase(type)) {
				Code39Writer code39Writer = new Code39Writer();
				
				Map<EncodeHintType, Object> hints = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
				hints.put(EncodeHintType.MARGIN, -1);
				
				bitMatrix = code39Writer.encode(text, BarcodeFormat.CODE_39, size.width, size.height, hints);
				
				
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		if(bitMatrix != null) {
			bufferedImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
		}
		
		
		return bufferedImage;
	}
}
