package com.barcode.test;

import java.io.Serializable;

import org.codehaus.jackson.JsonNode;

public class Position implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public int x;
	public int y;
	

	public Position() {
	}
	
	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public static Position deserialize(JsonNode positionNode) {
		if(positionNode == null) return null;
		Position point = new Position(positionNode.get("x").getIntValue(), positionNode.get("y").getIntValue());
		return point;
	}
}
