package com.barcode.test;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateUtils extends org.apache.commons.lang3.time.DateUtils
{

	private static final Logger	LOG	= LoggerFactory.getLogger(DateUtils.class);





	public static String getDate(String dateFormat)
	{
		SimpleDateFormat df = new SimpleDateFormat(dateFormat, Locale.getDefault());
		return df.format(new Date());
	}





	/**
	 * 문자열로 현재시간을 출력한다.
	 * 
	 * @param dateFormat
	 *            'Date and Time Patterns' 에 맞춘 문자열
	 * @return dateFormat에 형식에 맞춰 현재시간을 문자열로 리턴
	 */
	public static String getCurrentDate(String dateFormat)
	{
		SimpleDateFormat df = new SimpleDateFormat(dateFormat, Locale.getDefault());
		return df.format(new Date());
	}





	public static String getDate(Date date, String dateFormat)
	{
		SimpleDateFormat df = new SimpleDateFormat(dateFormat, Locale.getDefault());
		return df.format(date);
	}





	/**
	 * 인자로 넘어온 dateFormat 패턴으로 calendar의 시간을 출력.
	 * 
	 * @param dateFormat
	 *            'Date and Time Patterns' 에 맞춘 문자열
	 * @param calendar
	 *            Calendar
	 * @return
	 */
	public static String getDate(String dateFormat, Calendar calendar)
	{
		return new SimpleDateFormat(dateFormat, Locale.getDefault()).format(calendar.getTime());
	}





	public static Date convertStringToDate(String aMask, String strDate) throws ParseException
	{
		SimpleDateFormat df = new SimpleDateFormat(aMask, Locale.getDefault());

		Date date;
		try
		{
			date = df.parse(strDate);
		}
		catch ( ParseException pe )
		{
			LOG.error(pe.getMessage());
			throw new ParseException("Date Parsing Error", pe.getErrorOffset());
		}
		return date;
	}





	public static Date convertStringToDate(String aMask, String strDate, Locale locale) throws ParseException
	{
		SimpleDateFormat df = new SimpleDateFormat(aMask, locale);

		Date date = null;
		try
		{
			date = df.parse(strDate.replaceAll("-", "."));
		}
		catch ( ParseException pe )
		{
			LOG.error(pe.getMessage());
			throw new ParseException("Date Parsing Error", pe.getErrorOffset());
		}
		return date;
	}





	public static Date getToday(String aMask) throws ParseException
	{
		String currentDate = DateUtils.getDate(new Date(), aMask);
		Date getDate = null;
		getDate = convertStringToDate(currentDate);
		return getDate;
	}





	public static Date convertStringToDate(String strDate) throws ParseException
	{
		return convertStringToDate("yyyyMMdd", strDate);
	}





	public static Timestamp convertStringToTimestamp(String strDate) throws ParseException
	{
		return convertDateToTimestamp(convertStringToDate("yyyyMMdd", strDate));
	}





	public static String convertDateToString(String datePattern, Date date)
	{
		SimpleDateFormat df = null;
		String returnValue = "";
		// if(date == null)
		// {
		// log.error("aDate is null!");
		// } else
		// {
		df = new SimpleDateFormat(datePattern, Locale.getDefault());
		returnValue = df.format(date);
		// }
		return returnValue;
	}





	public static String convertDateToString(Date date)
	{
		return convertDateToString("yyyyMMdd", date);
	}





	public static Date getToday()
	{
		return new Date(System.currentTimeMillis());
	}





	public static Timestamp getCurrentTimestamp()
	{
		return new Timestamp(System.currentTimeMillis());
	}





	public static Date getPrevDate(Date date, int year, int month, int day)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if ( year != 0 )
		{
			calendar.add(Calendar.YEAR, year);
		}
		if ( month != 0 )
		{
			calendar.add(Calendar.MONTH, month);
		}
		if ( day != 0 )
		{
			calendar.add(Calendar.DAY_OF_MONTH, day);
		}
		return calendar.getTime();
	}





	public static List<String> getDurationStrList(String datePattern, Date prevDay, Date today)
	{
		Date sToday = today;

		List<String> dayList = new ArrayList<String>();
		Calendar calendar = Calendar.getInstance();

		int durationDiv = -1;
		if ( datePattern.contains("dd") )
		{
			durationDiv = Calendar.DAY_OF_MONTH;
		}
		else if ( datePattern.contains("MM") )
		{
			durationDiv = Calendar.MONTH;
		}
		else if ( datePattern.contains("yy") )
		{
			durationDiv = Calendar.YEAR;
		}
		while ( sToday.compareTo(prevDay) != -1 )
		{
			dayList.add(convertDateToString(datePattern, sToday));
			calendar.setTime(sToday);
			calendar.add(durationDiv, -1);
			sToday = calendar.getTime();
		}
		return dayList;
	}





	public static boolean dateDuplicateCheck(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate)
	{
		int intDBStartDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", startDate));
		int intDBEndDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", endDate));
		int intRegistStartDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", compareStartDate));
		int intRegistEndDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", compareEndDate));

		if ( intRegistEndDate < intDBStartDate && intRegistStartDate < intDBStartDate )
		{
			return true;
		}
		else if ( intRegistStartDate > intDBEndDate && intRegistEndDate > intDBEndDate )
		{
			return true;
		}
		else
		{
			return false;
		}
	}





	public static int getCalculateDay(Date startDate, Date endDate)
	{
		long dayTime = 1000 * 60 * 60 * 24;
		long endDateTime = endDate.getTime();
		long startDateTime = startDate.getTime();

		long durationTime = endDateTime - startDateTime;
		int day = (int) (durationTime / dayTime);

		return day;
	}





	public static Date getExpirationDate(Date date)
	{
		if ( date == null )
		{
			return null;
		}

		return getExpirationCalendar(date).getTime();
	}





	public static Timestamp getExpirationDate(Timestamp date)
	{
		if ( date == null )
		{
			return null;
		}

		return new Timestamp(getExpirationCalendar(date).getTimeInMillis());
	}





	private static Calendar getExpirationCalendar(Date date)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setLenient(false);
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar;
	}





	/**
	 * <pre>
	 * 1. Summary : XMLGregorianCalendar 형식으로 date 가져오는 함수
	 * 2. Details : 
	 * 
	 * 3. LastModifiedDate : 
	 * 4. LastReviewedDate : 13. 02. 14
	 * 5. History
	 * 		2013. 3. 18. writing comments
	 * 
	 * </pre>
	 * 
	 * @Method Name : getXMLGregorianCalendar
	 * @return
	 * @throws DatatypeConfigurationException
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendar() throws DatatypeConfigurationException
	{
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		//factory 에 인스턴스를 요청하고있다. thread safe가 보장된다면 static field로 DatatypeFactory 인스턴스를 하나만 두면 더 좋을 듯 하다. (단, 신중히 판단)
		DatatypeFactory factory = DatatypeFactory.newInstance();

		return factory.newXMLGregorianCalendar(gregorianCalendar);
	}





	public static XMLGregorianCalendar getXMLGregorianCalendar(long millis) throws DatatypeConfigurationException
	{
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTimeInMillis(millis);
		DatatypeFactory factory = DatatypeFactory.newInstance();

		return factory.newXMLGregorianCalendar(gregorianCalendar);
	}





	// 인자로 받는 년,월의 마지막 날짜 리턴
	public static int getDayOfMonth(int year, int month)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, month - 1);
		return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
	}





	public static Long getDuration(Date startDate, Date endDate)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		long startTime = calendar.getTimeInMillis();
		calendar.setTime(endDate);
		long endTime = calendar.getTimeInMillis();
		long durationTime = endTime - startTime;
		if ( durationTime > 999999 )
		{
			durationTime = 999999;
		}
		return durationTime;
	}





	public static boolean isExpired(Date startDate, Date endDate)
	{
		int getTodayDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", getToday()));
		//int getStartDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", startDate));
		int getEndDate = new Integer(DateUtils.convertDateToString("yyyyMMdd", endDate));

		// 만료되지 않음
		if ( getTodayDate <= getEndDate )
		{
			return false;
		}
		// 만료되었음
		else
		{
			return true;
		}
	}





	public static boolean isValidDate(final Date startDate, final Date endDate)
	{
		Date today = getToday();

		if ( startDate.compareTo(today) >= 0 )
		{
			return false;
		}

		if ( endDate.compareTo(today) < 0 )
		{
			return false;
		}

		return true;
	}





	public static boolean isValidTimestamp(final Timestamp startDate, final Timestamp endDate)
	{
		Timestamp today = getCurrentTimestamp();

		if ( startDate.compareTo(today) >= 0 )
		{
			return false;
		}

		if ( endDate.compareTo(today) < 0 )
		{
			return false;
		}

		return true;
	}





	/**
	 * 현재 날짜에서 변경 요청한 월+일 더하거나 빼서
	 * 
	 * @param str
	 *            날자
	 * @param val
	 *            숫자 (일수) 집어넣기
	 * @return yyyyMMdd 형식의 날짜가 담긴 날짜
	 * @throws ParseException
	 */
	public static Date getPreviosDay(Date str, int val, String fmf) throws ParseException
	{
		SimpleDateFormat fmt = new SimpleDateFormat(fmf, Locale.getDefault());
		java.util.Calendar c = java.util.Calendar.getInstance();
		java.util.Date date = null;

		try
		{
			date = fmt.parse(fmt.format(str));
			c.setTime(date);
			c.add(java.util.Calendar.DAY_OF_WEEK, val);

		}
		catch ( Exception ex )
		{
			LOG.warn(ex.getMessage(), ex);
		}
		return c.getTime();

		//return DateUtils.convertStringToDate(fmf, fmt.format(c.getTime()), Locale.KOREA);

	}





	/**
	 * 월 Add
	 * 
	 * <pre>
	 * 1. 개요 : 
	 * 2. 처리 내용 :
	 * </pre>
	 * 
	 * @Method Name : getDateMonthAdd
	 * @param dateFormat
	 * @return
	 */
	public static String getDateMonthAdd(int month, String format)
	{
		Calendar calendar = Calendar.getInstance();

		calendar.setTime(new Date());

		if ( month != 0 )
		{
			calendar.add(Calendar.MONTH, month);
		}

		return DateUtils.convertDateToString(format, calendar.getTime());
	}





	/**
	 * 월 Add
	 * 
	 * <pre>
	 * 1. 개요 : 
	 * 2. 처리 내용 :
	 * </pre>
	 * 
	 * @Method Name : getDateMonthAdd
	 * @param dateFormat
	 * @return
	 */

	public static String getYearMonthDateAdd(int year, int month, int day, String format)
	{
		Calendar calendar = Calendar.getInstance();

		calendar.setTime(new Date());
		Date test = getPrevDate(calendar.getTime(), year, month, day);

		return DateUtils.convertDateToString(format, test);
	}





	/**
	 * 
	 * <pre>
	 * 1. 개요 : 
	 * 2. 처리 내용 :
	 * </pre>
	 * 
	 * @Method Name : getAddDate
	 * @param date
	 * @param hh
	 * @param mm
	 * @param ss
	 * @return
	 */
	public static Date getAddDate(Date date, int hh, int mm, int ss)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if ( hh != 0 )
		{
			calendar.add(Calendar.HOUR, hh);
		}
		if ( mm != 0 )
		{
			calendar.add(Calendar.MINUTE, mm);
		}
		if ( ss != 0 )
		{
			calendar.add(Calendar.SECOND, ss);
		}
		return calendar.getTime();
	}





	public static Timestamp convertDateToTimestamp(Date date)
	{
		return new Timestamp(date.getTime());
	}
}
