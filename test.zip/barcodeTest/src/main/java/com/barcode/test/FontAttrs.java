package com.barcode.test;

import java.awt.Font;
import java.awt.font.TextAttribute;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FontAttrs implements Serializable {
	private static Logger log = LoggerFactory.getLogger(FontAttrs.class);
	private static final long serialVersionUID = 1L;
	public static final String STYLE_PLAIN			= "plain";
	public static final String STYLE_BOLD			= "bold";
	public static final String STYLE_EXTRA_BOLD		= "extraBold";
	
	protected String name;
	protected String style;
	protected int size;
	protected float tracking;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	protected Float getWeight() {
		if(STYLE_EXTRA_BOLD.equalsIgnoreCase(style)) {
			return TextAttribute.WEIGHT_EXTRABOLD;
		} else if(STYLE_BOLD.equalsIgnoreCase(style)) {
			return TextAttribute.WEIGHT_BOLD;
		}
		return TextAttribute.WEIGHT_REGULAR;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public float getTracking() {
		return tracking;
	}
	public void setTracking(float tracking) {
		this.tracking = tracking;
	}
	
	public Font derivedFont(Font font) {
		Font result = font;
		
		Map<TextAttribute, Object> attributes = new HashMap<TextAttribute, Object>();
		attributes.put(TextAttribute.TRACKING, tracking);
		attributes.put(TextAttribute.SIZE, size);
		attributes.put(TextAttribute.WEIGHT, getWeight());
		
		if(name != null) {
			attributes.put(TextAttribute.FAMILY, name);
			result = new Font(attributes);

			log.debug("new Font" + result);
			log.debug("result.getAttributes().get(TextAttribute.WEIGHT):" + result.getAttributes().get(TextAttribute.WEIGHT));
		} else {
			result = font.deriveFont(attributes);
		}
		
		return result;
	}
	


	public static FontAttrs deserialize(JsonNode node) {
		if(node == null) return null;
		FontAttrs fontAttrs = new FontAttrs();
		
		if(node.has("name")) {
			fontAttrs.name = node.get("name").getTextValue();
		}

		if(node.has("style")) {
			fontAttrs.style = node.get("style").getTextValue();
		}

		if(node.has("size")) {
			fontAttrs.size = node.get("size").getIntValue();
		}

		if(node.has("tracking")) {
			fontAttrs.tracking = (float)node.get("tracking").getDoubleValue();
		}
		
		return fontAttrs;
	}
}
