package com.barcode.test;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.module.SimpleModule;
import org.codehaus.jackson.type.TypeReference;

import net.sf.image4j.util.ConvertUtil;


public class CardImage extends Layout {
	private static final long serialVersionUID = 1L;
	
	protected String kind;
	protected ArrayList<View> frontImages;
	protected ArrayList<View> backImages;
	
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}

	public List<View> getFrontImages() {
		return frontImages;
	}
	
	public List<View> getBackImages() {
		return backImages;
	}
	
	protected void deserialize(JsonNode node) {
		super.deserialize(node);
		
		if(node.has("kind")) {
			kind = node.get("kind").getTextValue();
		}

		ObjectMapper objectMapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule("ViewDeserializer", new Version(1, 0, 0, null));
        simpleModule.addDeserializer(View.class, new ViewDeserializer());
        objectMapper.registerModule(simpleModule);
		
		if(node.has("frontImages")) {
	        frontImages = objectMapper.convertValue(node.get("frontImages"), new TypeReference<ArrayList<View>>(){});
		}
		
		if(node.has("backImages")) {
			backImages = objectMapper.convertValue(node.get("backImages"), new TypeReference<ArrayList<View>>(){});
		}
	}
	
	@Override
	protected void init() {
		super.init();
		
		if(frontImages != null) {
			for(View child:frontImages) {
				child.setParent(this);
				child.init();
			}
        }
		
		if(backImages != null) {
			for(View child:backImages) {
				child.setParent(this);
				child.init();
			}
        }
	}
	
	@Override
	public void draw(Map<String, Object> map) {
		super.draw(map);
		if(frontImages != null) {
			for(View child:frontImages) {
				child.draw(map);
			}
        }
		
		if(backImages != null) {
			for(View child:backImages) {
				child.draw(map);
			}
        }
	}

	public void save(String path) throws IOException {
		for(View child:frontImages) {
			Layout layout = (Layout)child;

			File outputfile = new File(path + "/" + layout.getTag() + ".png");
			ImageIO.write(layout.getBufferedImage(), "png", outputfile);
		}
		
		for(View child:backImages) {
			Layout layout = (Layout)child;

			File outputfile = new File(path + "/" + layout.getTag() + ".png");
			ImageIO.write(layout.getBufferedImage(), "png", outputfile);
		}
	}


	public static BufferedImage convertBit(int colorType, BufferedImage image) throws IOException {
		BufferedImage transImage = image;
		/*switch(colorType) {
		case 1:
			transImage = ConvertUtil.convert1(transImage);
			break;
		case 4:
			transImage = ConvertUtil.convert4(transImage);
			break;
		case 8:
			transImage = ConvertUtil.convert8(transImage);
			break;
		}*/
	
		return transImage;
	}
	
	public static byte[] toByteArray(int colorType, BufferedImage image) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(convertBit(colorType, image), "BMP", baos);
		baos.flush();
		byte[] imageInByte = baos.toByteArray();
		baos.close();
		
		return imageInByte;
	}
}
