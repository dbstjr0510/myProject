package com.barcode.test;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.module.SimpleModule;
import org.codehaus.jackson.type.TypeReference;

public abstract class Layout extends View {
	private static final long serialVersionUID = 1L;

	protected BufferedImage bufferedImage;
	
	protected int colorType;
	
	private ArrayList<View> children = new ArrayList<View>();
	
	public BufferedImage getBufferedImage() {
		return bufferedImage;
	}

	protected void setBufferedImage(BufferedImage bufferedImage) {
		this.bufferedImage = bufferedImage;
	}


	public int getColorType() {
		return colorType;
	}

	public void setColorType(int colorType) {
		this.colorType = colorType;
	}

	public ArrayList<View> getChildren() {
		return children;
	}

	public void setChildren(ArrayList<View> children) {
		this.children = children;
	}
	
	protected void deserialize(JsonNode node) {
		super.deserialize(node);
		
		if(node.has("colorType")) {
			colorType = node.get("colorType").getIntValue();
		}

		ObjectMapper objectMapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule("ViewDeserializer", new Version(1, 0, 0, null));
        simpleModule.addDeserializer(View.class, new ViewDeserializer());
        objectMapper.registerModule(simpleModule);
		
		if(node.has("children")) {
			children = objectMapper.convertValue(node.get("children"), new TypeReference<ArrayList<View>>(){});
		}
	}
	
	@Override
	protected void init() {
		super.init();
		
		if(children != null) {
			for(View child:children) {
				child.setParent(this);
				child.init();
			}
        }
	}

	@Override
	public void draw(Map<String, Object> map) {
		super.draw(map);
		if(bufferedImage == null) {
			bufferedImage = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);
		}
		
		Graphics2D graphics = (Graphics2D) bufferedImage.getGraphics();
		
		draw(graphics, map);
	}

	@Override
	protected void draw(Graphics2D graphics, Map<String, Object> map) {
		super.draw(graphics, map);

		if(backgroundColor != null) {
			graphics.setBackground(backgroundColor);
			graphics.clearRect(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight());
		}
		
		if(children != null) {
			for(View child:children) {
				child.draw(graphics, map);
			}
        }
	}
	
	public byte[] toByteArray(String type) throws IOException {
		if(bufferedImage == null) return null;
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, type, baos);
		baos.flush();
		byte[] imageInByte = baos.toByteArray();
		baos.close();
		
		return imageInByte;
	}

}
