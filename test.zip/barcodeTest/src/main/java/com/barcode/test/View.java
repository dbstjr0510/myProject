package com.barcode.test;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class View implements Serializable {
	private static Logger log = LoggerFactory.getLogger(View.class);
	private static final long serialVersionUID = 1L;
	
	public static final String ALIGN_LEFT		 = "left";
	public static final String ALIGN_RIGHT		 = "right";

	protected View parent;
	protected String tag;
	protected Size size;
	protected Position position;
	protected Color color;
	protected Color backgroundColor;
	protected int align;
	protected FontAttrs fontAttrs;
	protected Font font;
	
	public View getParent() {
		return parent;
	}
	public void setParent(View parent) {
		this.parent = parent;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public Size getSize() {
		return size;
	}
	public void setSize(Size size) {
		this.size = size;
	}
	public Position getPosition() {
		return position;
	}
	public void setPosition(Position position) {
		this.position = position;
	}
	public Color getColor() {
		if(color == null && parent != null) {
			return parent.getColor();
		}
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public Color getBackgroundColor() {
		if(backgroundColor == null && parent != null) {
			return parent.getBackgroundColor();
		}
		return backgroundColor;
	}
	public void setBackgroundColor(Color backgroundColor) {
		this.backgroundColor = backgroundColor;
	}
	public int getAlign() {
		return align;
	}
	public void setAlign(int align) {
		this.align = align;
	}
	public Font getFont() {
		if(font == null && parent != null) {
			return parent.getFont();
		}
		return font;
	}
	public void setFont(Font font) {
		this.font = font;
	}
	public FontAttrs getFontAttrs() {
		return fontAttrs;
	}
	public void setFontAttrs(FontAttrs fontAttrs) {
		this.fontAttrs = fontAttrs;
	}
	
	protected void deserialize(JsonNode node) {
		
		if(node.has("tag")) {
			tag = node.get("tag").getTextValue();
		}
		
		if(node.has("size")) {
			size = Size.deserialize(node.get("size"));
		}
		
		if(node.has("position")) {
			position = Position.deserialize(node.get("position"));
		}

		if(node.has("color")) {
			color = hex2Rgb(node.get("color").getTextValue());
		}

		if(node.has("backgroundColor")) {
			backgroundColor = hex2Rgb(node.get("backgroundColor").getTextValue());
		}
		
		if(node.has("align")) {
			align = node.get("align").getIntValue();
		}
		
		if(node.has("fontAttrs")) {
			fontAttrs = FontAttrs.deserialize(node.get("fontAttrs"));
		}
	}
	
	protected void init() {
		initFont();
	}
	
	protected void initFont() {
		if(fontAttrs != null) {
			font = fontAttrs.derivedFont(getFont());
		}
	}
	
	public void draw(Map<String, Object> map) {
		log.debug(this.getClass().getSimpleName() + ".draw:[" + tag +"]");
	}
	
	protected void draw(Graphics2D graphics, Map<String, Object> map) {
		log.debug(this.getClass().getSimpleName() + ".draw:[" + tag +"]");
	}
	
	public static Color hex2Rgb(String colorStr) {
		Color color = null;
		if(colorStr.length() > 8) {
			color = new Color(
		            Integer.valueOf( colorStr.substring( 3, 5 ), 16 ),
		            Integer.valueOf( colorStr.substring( 5, 7 ), 16 ),
		            Integer.valueOf( colorStr.substring( 7, 9 ), 16 ),
		            Integer.valueOf( colorStr.substring( 1, 3 ), 16 ));
		} else {
			color = new Color(
		            Integer.valueOf( colorStr.substring( 1, 3 ), 16 ),
		            Integer.valueOf( colorStr.substring( 3, 5 ), 16 ),
		            Integer.valueOf( colorStr.substring( 5, 7 ), 16 ) );
		}
		return color;
	}
}
