
package com.barcode.test;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;


public class test123124 {

	

	public static void main(String[] args) {
		Timestamp issueDt = DateUtils.getCurrentTimestamp();
		Long num = 22L;
		System.out.println(issueDt);
		issueDt.setHours(22);
		System.out.println(issueDt);
		
		Calendar cal = Calendar.getInstance();
		System.out.println(cal);
		Date d = new Date(cal.getTimeInMillis()); 
		System.out.println(d);
		
		cal.set(Calendar.HOUR_OF_DAY, 22);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		d = new Date(cal.getTimeInMillis()); 
		System.out.println(d);
		Timestamp t = DateUtils.convertDateToTimestamp(d);
		System.out.println(t);
	}

}
