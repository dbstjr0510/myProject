package com.barcode.test;

import java.util.Map;

import org.codehaus.jackson.JsonNode;

public abstract class AttrView extends View {
	private static final long serialVersionUID = 1L;
	
	protected String attrKey;
	
	@Override
	protected void deserialize(JsonNode node) {
		super.deserialize(node);
		
		if(node.has("attrKey")) {
			attrKey = node.get("attrKey").getTextValue();
		}
	}
	
	protected Object getData(Map<String, Object> data) {
		return data.get(attrKey);
	}
	
	protected String getStringData(Map<String, Object> data) {
		return (String)data.get(attrKey);
	}
}
